<?php
// Run this file ONCE after importing database.sql, then delete this file.
require_once "db.php";

$username = "admin";
$email = "admin@gmail.com";
$plainPassword = "admin123";
$hashedPassword = password_hash($plainPassword, PASSWORD_DEFAULT);
$role = "admin";

$stmt = $conn->prepare(
    "INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)"
);
$stmt->bind_param("ssss", $username, $email, $hashedPassword, $role);

if ($stmt->execute()) {
    echo "Admin created successfully. Username: admin | Password: admin123";
} else {
    echo "Admin may already exist. Database message: " . htmlspecialchars($stmt->error);
}

$stmt->close();
$conn->close();
?>
