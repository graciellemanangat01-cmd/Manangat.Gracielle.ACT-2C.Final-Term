<?php
$conn = new mysqli("localhost", "root", "", "user_management");

if ($conn->connect_error) {
    die("Database connection failed. Check that MySQL is running.");
}

$conn->set_charset("utf8mb4");
?>
