ACTIVITY #2 - USER MANAGEMENT SYSTEM
PHP + MySQL + HTML + CSS

PROJECT FILES
- database.sql
- db.php
- setup_admin.php
- index.php

REQUIREMENTS
- XAMPP
- Apache and MySQL
- Visual Studio Code (or another code editor)

INSTALLATION
1. Extract Activity2_User_Management.zip.
2. Copy the Activity2_User_Management folder into your XAMPP htdocs folder.
3. Start Apache and MySQL in XAMPP.
4. Open http://localhost/phpmyadmin
5. Open the SQL tab and run the contents of database.sql.
6. Visit http://localhost/Activity2_User_Management/setup_admin.php ONCE.
7. After the admin is created, delete setup_admin.php from the project folder.
8. Visit http://localhost/Activity2_User_Management/index.php.

SAMPLE ADMIN LOGIN
Username: admin
Password: admin123

FEATURES
- User registration (new accounts receive the regular user role)
- Login and logout
- Access control (admin and user roles)
- Create users
- Read/display users
- Update users
- Delete users
- Password hashing
- Prepared SQL statements
- CSRF token validation

NOTES
- The admin can manage users.
- A regular user can log in but cannot access user-management actions.
- The admin cannot delete their own currently logged-in account.
- Change the sample admin password before using this outside a local classroom demo.
- Do not leave setup_admin.php on the server after creating the first admin.
