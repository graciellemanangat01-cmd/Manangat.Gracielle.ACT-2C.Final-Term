<?php
session_start();
require_once "db.php";

if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}

function verify_csrf() {
    if (
        !isset($_POST["csrf_token"], $_SESSION["csrf_token"]) ||
        !hash_equals($_SESSION["csrf_token"], $_POST["csrf_token"])
    ) {
        http_response_code(403);
        exit("Invalid request. Please go back and try again.");
    }
}

function require_admin() {
    if (
        !isset($_SESSION["user_id"], $_SESSION["role"]) ||
        $_SESSION["role"] !== "admin"
    ) {
        http_response_code(403);
        exit("Access denied. Administrator permission required.");
    }
}

$message = "";

// LOGOUT
if (isset($_GET["logout"])) {
    $_SESSION = [];
    session_destroy();
    header("Location: index.php");
    exit;
}

// LOGIN
if (isset($_POST["login"])) {
    verify_csrf();

    $username = trim($_POST["username"] ?? "");
    $password = $_POST["password"] ?? "";

    $stmt = $conn->prepare("SELECT id, username, password, role FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if ($user && password_verify($password, $user["password"])) {
        session_regenerate_id(true);
        $_SESSION["user_id"] = (int)$user["id"];
        $_SESSION["username"] = $user["username"];
        $_SESSION["role"] = $user["role"];
        header("Location: index.php");
        exit;
    }

    $message = "Invalid username or password.";
}

// REGISTER - public registrations are always regular users
if (isset($_POST["register"])) {
    verify_csrf();

    $username = trim($_POST["username"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";

    if ($username === "" || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Enter a username and valid email address.";
    } elseif (strlen($password) < 6) {
        $message = "Password must be at least 6 characters.";
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare(
            "INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, 'user')"
        );
        $stmt->bind_param("sss", $username, $email, $hash);

        if ($stmt->execute()) {
            $message = "Registration successful. You can now log in.";
        } else {
            $message = "Username or email already exists.";
        }
    }
}

// CREATE USER - ADMIN ONLY
if (isset($_POST["add_user"])) {
    require_admin();
    verify_csrf();

    $username = trim($_POST["username"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";
    $role = $_POST["role"] ?? "user";

    if ($username === "" || !filter_var($email, FILTER_VALIDATE_EMAIL) ||
        strlen($password) < 6 || !in_array($role, ["admin", "user"], true)) {
        $message = "Check the user details. Password must be at least 6 characters.";
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare(
            "INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)"
        );
        $stmt->bind_param("ssss", $username, $email, $hash, $role);

        if ($stmt->execute()) {
            header("Location: index.php");
            exit;
        }
        $message = "Could not add user. Username or email may already exist.";
    }
}

// UPDATE USER - ADMIN ONLY
if (isset($_POST["update_user"])) {
    require_admin();
    verify_csrf();

    $id = (int)($_POST["id"] ?? 0);
    $username = trim($_POST["username"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $role = $_POST["role"] ?? "user";

    if ($id < 1 || $username === "" ||
        !filter_var($email, FILTER_VALIDATE_EMAIL) ||
        !in_array($role, ["admin", "user"], true)) {
        $message = "Check the updated user information.";
    } else {
        $stmt = $conn->prepare(
            "UPDATE users SET username = ?, email = ?, role = ? WHERE id = ?"
        );
        $stmt->bind_param("sssi", $username, $email, $role, $id);

        if ($stmt->execute()) {
            header("Location: index.php");
            exit;
        }
        $message = "Could not update user. Username or email may already exist.";
    }
}

// DELETE USER - ADMIN ONLY; cannot delete own active account
if (isset($_POST["delete_user"])) {
    require_admin();
    verify_csrf();

    $id = (int)($_POST["id"] ?? 0);

    if ($id === (int)$_SESSION["user_id"]) {
        $message = "You cannot delete your own logged-in account.";
    } elseif ($id > 0) {
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        header("Location: index.php");
        exit;
    }
}

// READ USERS - ADMIN ONLY
$users = [];
if (
    isset($_SESSION["user_id"], $_SESSION["role"]) &&
    $_SESSION["role"] === "admin"
) {
    $result = $conn->query(
        "SELECT id, username, email, role, created_at FROM users ORDER BY id DESC"
    );
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>User Management System</title>
<style>
* { box-sizing: border-box; }
body { font-family: Arial, sans-serif; background: #f2f2f2; margin: 0; padding: 24px; color: #222; }
.container { max-width: 1100px; margin: auto; background: #fff; padding: 24px; border-radius: 8px; }
h1, h2 { text-align: center; }
.form-box { max-width: 430px; margin: 18px auto; }
input, select { width: 100%; padding: 10px; margin: 6px 0; border: 1px solid #bbb; border-radius: 4px; }
button { padding: 10px 15px; cursor: pointer; border: 0; border-radius: 4px; background: #222; color: white; }
button:hover { opacity: .85; }
.message { text-align: center; color: #176b36; }
.top { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; }
table { width: 100%; border-collapse: collapse; margin-top: 18px; }
th, td { border: 1px solid #ccc; padding: 9px; text-align: left; vertical-align: top; }
th { background: #eee; }
.actions { min-width: 230px; }
.actions form { margin: 4px 0; }
@media (max-width: 700px) {
  body { padding: 8px; }
  .container { padding: 12px; overflow-x: auto; }
  table { min-width: 850px; }
}
</style>
</head>
<body>
<div class="container">
<h1>USER MANAGEMENT SYSTEM</h1>

<?php if ($message !== ""): ?>
<p class="message"><?php echo e($message); ?></p>
<?php endif; ?>

<?php if (!isset($_SESSION["user_id"])): ?>

<h2>LOGIN</h2>
<form method="POST" class="form-box">
    <input type="hidden" name="csrf_token" value="<?php echo e($_SESSION["csrf_token"]); ?>">
    <input type="text" name="username" placeholder="Username" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit" name="login">Login</button>
</form>

<hr>
<h2>REGISTER</h2>
<form method="POST" class="form-box">
    <input type="hidden" name="csrf_token" value="<?php echo e($_SESSION["csrf_token"]); ?>">
    <input type="text" name="username" placeholder="Username" required>
    <input type="email" name="email" placeholder="Email address" required>
    <input type="password" name="password" placeholder="Password (minimum 6 characters)" minlength="6" required>
    <button type="submit" name="register">Register</button>
</form>

<?php else: ?>

<div class="top">
    <p>Welcome, <strong><?php echo e($_SESSION["username"]); ?></strong>
       | Role: <strong><?php echo e($_SESSION["role"]); ?></strong></p>
    <a href="index.php?logout=1">Logout</a>
</div>

<?php if ($_SESSION["role"] === "admin"): ?>

<hr>
<h2>ADD NEW USER</h2>
<form method="POST" class="form-box">
    <input type="hidden" name="csrf_token" value="<?php echo e($_SESSION["csrf_token"]); ?>">
    <input type="text" name="username" placeholder="Username" required>
    <input type="email" name="email" placeholder="Email address" required>
    <input type="password" name="password" placeholder="Password (minimum 6 characters)" minlength="6" required>
    <select name="role">
        <option value="user">User</option>
        <option value="admin">Admin</option>
    </select>
    <button type="submit" name="add_user">Add User</button>
</form>

<hr>
<h2>USER LIST</h2>
<table>
<thead>
<tr>
    <th>ID</th><th>Username</th><th>Email</th>
    <th>Role</th><th>Created</th><th>Actions</th>
</tr>
</thead>
<tbody>
<?php foreach ($users as $row): ?>
<tr>
    <td><?php echo e($row["id"]); ?></td>
    <td><?php echo e($row["username"]); ?></td>
    <td><?php echo e($row["email"]); ?></td>
    <td><?php echo e($row["role"]); ?></td>
    <td><?php echo e($row["created_at"]); ?></td>
    <td class="actions">
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo e($_SESSION["csrf_token"]); ?>">
            <input type="hidden" name="id" value="<?php echo e($row["id"]); ?>">
            <input type="text" name="username" value="<?php echo e($row["username"]); ?>" required>
            <input type="email" name="email" value="<?php echo e($row["email"]); ?>" required>
            <select name="role">
                <option value="user" <?php echo $row["role"] === "user" ? "selected" : ""; ?>>User</option>
                <option value="admin" <?php echo $row["role"] === "admin" ? "selected" : ""; ?>>Admin</option>
            </select>
            <button type="submit" name="update_user">Update</button>
        </form>

        <?php if ((int)$row["id"] !== (int)$_SESSION["user_id"]): ?>
        <form method="POST" onsubmit="return confirm('Delete this user?');">
            <input type="hidden" name="csrf_token" value="<?php echo e($_SESSION["csrf_token"]); ?>">
            <input type="hidden" name="id" value="<?php echo e($row["id"]); ?>">
            <button type="submit" name="delete_user">Delete</button>
        </form>
        <?php endif; ?>
    </td>
</tr>
<?php endforeach; ?>
</tbody>
</table>

<?php else: ?>
<h2>USER DASHBOARD</h2>
<p>You are logged in as a regular user. You do not have permission to manage accounts.</p>
<?php endif; ?>

<?php endif; ?>
</div>
</body>
</html>
